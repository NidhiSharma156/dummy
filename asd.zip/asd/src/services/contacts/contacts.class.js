const { Service } = require('feathers-mongoose');

exports.Contacts = class Contacts extends Service {

};
